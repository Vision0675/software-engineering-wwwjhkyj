// pages/release/release.js
const app = getApp()
const network = require("../../utils/network.js")
const { api } = require("../../utils/config.js")
const timeApi = require('../../utils/util.js');
const server = "http://47.101.183.63:8081";

Page({
  data: {
    // 1. 严格对齐 SRS 规定的任务分类
    taskTypes: ['跑腿代办', '学习互助', '技能服务'],
    taskType: '跑腿代办',
    
    imgs:[],
    title: '',
    description: '',
    money: 0,
    
    // 2. 新增位置信息相关变量
    locationName: '点击选择地图位置',
    latitude: 0,
    longitude: 0,
    
    endDate: "",
    endTime: '',
  },

  onLoad: function () {
    var now = timeApi.formatDate(new Date());
    var time = timeApi.formatTime(new Date());
    this.setData({
      endDate: now,
      endTime: time,
    })
  },

  // 3. 核心新功能：调用微信原生位置选择器
  chooseLocation: function() {
    let that = this;
    wx.chooseLocation({
      success: function(res) {
        that.setData({
          locationName: res.name || res.address, // 获取地名
          latitude: res.latitude,               // 获取纬度
          longitude: res.longitude              // 获取经度
        });
      },
      fail: function(err) {
        console.log("选择位置失败或取消", err);
      }
    });
  },

  chooseImg: function() {
    var that = this;
    var tempImgs = this.data.imgs;
    var len = tempImgs.length;
    wx.chooseImage({
      count: 9-len,
      sizeType: ['original', 'compressed'], 
      sourceType: ['album', 'camera'], 
      success: function(res) {
        var addImg = res.tempFilePaths;
        for(var i =0;i<addImg.length;i++){
          wx.uploadFile({
            url: api.uploadFile,
            filePath: addImg[i],
            name: 'myfiles',
            success: function (res2) {
              res2 = JSON.parse(res2.data)
              if (res2.success){
                tempImgs.push(server+res2.content);
                that.setData({ imgs: tempImgs })
              }
            },
            fail: function(res2) {
              wx.showToast({ title: '图片太大啦', icon: 'none', duration: 3000 })
            }
          })
        }
      }
    })
  },

  handleSubmit: function() {
    // 校验必填项
    if(!this.data.title){
      wx.showToast({ title: '请填写任务标题', icon: 'none' }); return;
    }
    if(this.data.locationName === '点击选择地图位置'){
      wx.showToast({ title: '请选择任务位置', icon: 'none' }); return;
    }

    // 4. 对齐后端的英文分类暗号
    var typeData="";
    if (this.data.taskType === '跑腿代办'){
      typeData='ERRAND';
    }else if(this.data.taskType === '学习互助'){
      typeData="STUDY";
    }else{
      typeData="SKILL";
    }

    network.POST({
      url: api.publish,
      data: {
        title: this.data.title,
        content: this.data.description,
        payment: this.data.money,
        // 传递位置和经纬度给后端
        location: this.data.locationName,
        latitude: this.data.latitude,
        longitude: this.data.longitude,
        
        end: this.data.endDate + " " + this.data.endTime + ":00",
        type: typeData,
        publisher: app.globalData.user.id,
        publisherIconUrl: app.globalData.user.avatar,
        pictureUrl: this.data.imgs.join("@")
      },
      success: res => {
        if (res.success) {
          wx.showToast({ title: '发布成功', icon: 'success', duration: 2000 })
          setTimeout(() => { wx.navigateBack({ delta: 1 }) }, 1500);
        } else {
          wx.showToast({ title: res.message || '发布失败', icon: 'none', duration: 2000 })
        }
      }
    })
  },

  bindInputTitle: function(e) { this.setData({ title: e.detail.detail.value }) },
  bindInputMoney: function (e) { this.setData({ money: e.detail.detail.value }) },
  bindInputDescription: function (e) { this.setData({ description: e.detail.detail.value }) },
  setTaskType: function(e) { this.setData({ taskType: this.data.taskTypes[e.detail.value] }) },
  setEndDate: function (e) { this.setData({ endDate: e.detail.value }) },
  setEndTime: function (e) { this.setData({ endTime: e.detail.value }) },
})