// index.js 
Page({
  data: {
    // 模拟用户信息 (对应 SRS 要求 1 & 5)
    userInfo: {
      authStatus: "已实名",
      points: 120,
      credit: 100
    },
    // 增强模拟数据 (对应 SRS 要求 2 & 4)
    taskList: [
      {
        id: "1001",
        title: "求帮忙去南区拿个顺丰大件快递",
        payment: "5.00",
        location: "南区菜鸟驿站",
        distance: 450, // 模拟计算出的距离
        status: "待接单",
        end: "2026-04-14 18:00",
        publisherIconUrl: "../../utils/imgs/defaultAvatar.gif",
        content: "包裹有点重，最好有小推车，送到南区 5 号楼下。"
      },
      {
        id: "1002",
        title: "C语言作业有几道题报错，求辅导",
        payment: "15.00",
        location: "图书馆二楼",
        distance: 800,
        status: "进行中",
        end: "2026-04-15 12:00",
        publisherIconUrl: "../../utils/imgs/defaultAvatar.gif",
        content: "主要关于指针和内存管理部分，有基础的同学来。"
      }
    ],
    taskTypes: ['跑腿代办', '学习互助', '技能服务'],
    taskType: "任务分类",
    // ... 其他原有 data 保持不变
  },

// 把这段贴在 data 的大括号下面：
toRelease: function() {
  const app = getApp();
  // 判断：如果是调试模式，或者用户信息已审核，就放行
  if (app.globalData.isDebug || (app.globalData.user && app.globalData.user.state == 'CHECKED')) {
    wx.navigateTo({
      url: '../release/release'
    });
  } else {
    // 暴力通车备用方案：如果还没配好 app.js，强制直接跳
    wx.navigateTo({
      url: '../release/release'
    });
  }
},

// 下面是原有的其他函数，比如 onLoad: function() { ... }

  // 对应 SRS 要求 3：即时通讯入口
  startChat: function() {
    if (this.data.userInfo.authStatus !== '已实名') {
      wx.showToast({ title: '请先完成学籍认证', icon: 'none' });
      return;
    }
    wx.showToast({ title: '正在连接通讯服务器...', icon: 'loading' });
    // 实际应跳转至聊天页面
  },

  // 对应 SRS 要求 6：举报入口
  toReport: function() {
    wx.showActionSheet({
      itemList: ['内容违规', '恶意刷单', '虚假任务', '其他'],
      success: (res) => {
        wx.showToast({ title: '举报已提交，后台审核中', icon: 'success' });
      }
    })
  },

  // ... 其余函数参考之前的 index.js 内容即可
})