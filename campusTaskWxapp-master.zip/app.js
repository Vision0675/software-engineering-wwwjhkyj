// app.js
const network = require("./utils/network.js") // 建议检查路径，通常是相对路径 ./
const { api } = require("./utils/config.js")
const timeApi = require('./utils/util.js');

App({
  onLaunch: function () {
    // 初始化用户信息
    this.globalData.user = {
      id: "mock_user_001", // 预设一个模拟ID，防止因为没有登录导致后续代码报错
      state: "CHECKED",    // 预设为已审核状态
      avatar: "../../utils/imgs/defaultAvatar.gif"
    };
  },
  globalData: {
    user: null,
    // 【新增】调试开关
    // true: 开发环境，跳过联网检查，方便你这个“1号位”画界面
    // false: 正式环境，开启联网检查，对接“2号位”的后端接口
    isDebug: true 
  }
})
