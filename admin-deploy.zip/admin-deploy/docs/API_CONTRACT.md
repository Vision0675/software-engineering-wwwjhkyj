# 共济校圈 - 后端 API 契约文档

## 1. 全局标准

### 1.1 基础地址
- **开发环境:** `http://localhost:8080/api/v1`
- **生产环境:** `https://api.gongji.edu.cn/api/v1`
- **管理后台:** `http://localhost:8081/admin`

### 1.2 通用请求头
- `Content-Type: application/json`
- `Authorization: Bearer <Token>`

### 1.3 标准响应格式
```json
{
  "code": 20000,
  "message": "success",
  "data": {}
}
```

| code | 含义 |
|------|------|
| 20000 | 成功 |
| 40000 | 参数错误 |
| 40100 | 未授权 |
| 40300 | 无权限 |
| 40400 | 资源不存在 |
| 50000 | 服务器错误 |

---

## 2. 业务 API (backend-server :8080)

### 2.1 用户认证

#### POST /api/v1/auth/register - 用户注册
```json
// Request
{ "Student_ID": "2024001", "Name": "张三", "Department": "计算机学院", "Phone": "13800138000", "OpenID": "wx_xxx" }
// Response
{ "code": 20000, "data": { "token": "...", "User_ID": "U_xxx", "Auth_Status": 0 } }
```

#### POST /api/v1/auth/login - 用户登录
```json
// Request
{ "OpenID": "wx_xxx" }
// Response
{ "code": 20000, "data": { "token": "...", "User_ID": "U_xxx", "Name": "张三" } }
```

#### GET /api/v1/user/profile - 获取个人信息
需要 Authorization Header，返回脱敏的用户信息。

#### PUT /api/v1/user/profile - 更新个人信息

### 2.2 任务管理

#### POST /api/v1/tasks - 发布任务
```json
// Request
{ "Task_Type": "跑腿代办", "Title": "帮取快递", "Description": "...", "Reward": 15.0, "Task_Location": "菜鸟驿站" }
// Response
{ "code": 20000, "data": { "Task_ID": "T_xxx", "Task_Status": 0 } }
```

#### GET /api/v1/tasks - 任务列表
Query: `?page=1&per_page=10&type=跑腿代办`

#### GET /api/v1/tasks/:id - 任务详情
#### POST /api/v1/tasks/:id/accept - 接单
#### POST /api/v1/tasks/:id/complete - 确认完成
#### POST /api/v1/tasks/:id/cancel - 取消任务
#### GET /api/v1/user/tasks/published - 我发布的
#### GET /api/v1/user/tasks/accepted - 我接的

### 2.3 即时通讯

#### GET /api/v1/tasks/:id/messages - 获取聊天记录
#### POST /api/v1/tasks/:id/messages - 发送消息
```json
// Request
{ "Content": "你好", "Msg_Type": 0 }
```

#### WebSocket - 实时通讯
连接: `ws://localhost:8080/socket.io/?user_id=U_xxx`
事件:
- `join_task` - 加入任务聊天室
- `send_message` - 发送消息
- `new_message` - 接收新消息

### 2.4 地图服务

#### GET /api/v1/map/tasks/nearby - 附近任务
Query: `?lng=121.49&lat=31.28&radius=3000`

---

## 3. 管理后台 API (admin_backend :8081)

### 3.1 仪表盘
`GET /admin/dashboard`

### 3.2 用户管理
- `GET /admin/users` - 用户列表
- `PUT /admin/users/:id/audit` - 审核用户 (`action: pass/reject/manual_review`)
- `PUT /admin/users/:id/violate` - 违规处罚

### 3.3 任务管理
- `GET /admin/tasks` - 任务列表
- `PUT /admin/tasks/:id/audit` - 审核任务 (`action: pass/reject/ai_flag`)
- `DELETE /admin/tasks/:id` - 删除任务

### 3.4 纠纷管理
- `GET /admin/disputes` - 纠纷列表
- `PUT /admin/disputes/:id/resolve` - 处理纠纷
