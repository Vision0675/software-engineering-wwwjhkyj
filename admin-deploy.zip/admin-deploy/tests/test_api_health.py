import pytest
import requests

API_URL = "http://localhost:8080/api/v1"
ADMIN_URL = "http://localhost:8081/admin"


class TestHealthCheck:
    """基础健康检查"""

    def test_backend_api_tasks_list(self):
        """测试业务后端：任务列表接口"""
        try:
            resp = requests.get(f"{API_URL}/tasks", timeout=5)
            assert resp.status_code == 200
            data = resp.json()
            assert data["code"] == 20000
            assert "tasks" in data["data"]
        except requests.ConnectionError:
            pytest.skip("业务后端 API 未启动")

    def test_backend_api_nearby(self):
        """测试业务后端：附近任务接口"""
        try:
            resp = requests.get(
                f"{API_URL}/map/tasks/nearby",
                params={"lng": 121.49, "lat": 31.28, "radius": 3000},
                timeout=5,
            )
            assert resp.status_code == 200
        except requests.ConnectionError:
            pytest.skip("业务后端 API 未启动")

    def test_admin_dashboard(self):
        """测试管理后台：仪表盘接口"""
        try:
            resp = requests.get(f"{ADMIN_URL}/dashboard", timeout=5)
            assert resp.status_code == 200
            data = resp.json()
            assert data["code"] == 20000
            assert "total_users" in data["data"]
        except requests.ConnectionError:
            pytest.skip("Admin 后端未启动")
