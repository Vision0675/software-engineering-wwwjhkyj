import pytest
import requests

GATEWAY_URL = "http://localhost:80"


class TestCampusTaskFlow:
    """校园任务核心业务流程联调测试"""

    def setup_class(self):
        self.publisher_id = None
        self.token = None
        self.test_task_id = None

    def test_01_register_user(self):
        """用户注册"""
        url = f"{GATEWAY_URL}/api/v1/auth/register"
        payload = {
            "Student_ID": "2024001",
            "Name": "测试用户",
            "Department": "计算机科学与技术学院",
            "Phone": "13800138000",
            "OpenID": "wx_test_2024001",
        }
        try:
            resp = requests.post(url, json=payload, timeout=5)
            data = resp.json()
            assert resp.status_code == 200
            assert "token" in data["data"]
            self.__class__.token = data["data"]["token"]
        except requests.ConnectionError:
            pytest.skip("后端未启动")

    def test_02_publish_task(self):
        """发布任务"""
        if not self.token:
            pytest.skip("上一步注册失败")

        url = f"{GATEWAY_URL}/api/v1/tasks"
        headers = {"Authorization": f"Bearer {self.token}"}
        payload = {
            "Task_Type": "跑腿代办",
            "Title": "帮取快递",
            "Description": "帮忙去菜鸟驿站取个快递",
            "Reward": 15.0,
            "Task_Location": "嘉定校区菜鸟驿站",
        }
        try:
            resp = requests.post(url, json=payload, headers=headers, timeout=5)
            data = resp.json()
            assert resp.status_code == 200
            assert data["code"] == 20000
            self.__class__.test_task_id = data["data"]["Task_ID"]
            assert data["data"]["Task_Status"] == 0  # 待审核
        except requests.ConnectionError:
            pytest.skip("后端未启动")

    def test_03_admin_audit_task(self):
        """管理员审核任务"""
        if not self.test_task_id:
            self.__class__.test_task_id = "T_MOCK_001"

        url = f"{GATEWAY_URL}/admin/tasks/{self.test_task_id}/audit"
        payload = {"action": "pass"}
        try:
            resp = requests.put(url, json=payload, timeout=5)
            data = resp.json()
            assert resp.status_code == 200
            assert data["data"]["Task_Status"] == 1  # 待接单
        except requests.ConnectionError:
            pytest.skip("Admin 后端未启动")

    def test_04_list_tasks(self):
        """查看任务大厅"""
        url = f"{GATEWAY_URL}/api/v1/tasks"
        try:
            resp = requests.get(url, timeout=5)
            data = resp.json()
            assert resp.status_code == 200
            assert len(data["data"]["tasks"]) >= 0
        except requests.ConnectionError:
            pytest.skip("后端未启动")
