from flask import Flask, request, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime, timedelta
import os

app = Flask(__name__, static_folder="static")
CORS(app)

app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv(
    "DB_URI", "sqlite:///campus_task.db"
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# ==========================================
# 数据模型 (严格按照 SRS 3.4)
# ==========================================

class User(db.Model):
    __tablename__ = "users"
    User_ID = db.Column(db.String(32), primary_key=True)
    Student_ID = db.Column(db.String(20), unique=True, nullable=False)
    Name = db.Column(db.String(50), nullable=False, default="")
    Department = db.Column(db.String(50), nullable=False, default="")
    Phone = db.Column(db.String(11), nullable=False, default="")
    Credit_Score = db.Column(db.Integer, default=100)
    Point_Balance = db.Column(db.Integer, default=0)
    Auth_Status = db.Column(db.Integer, default=0, comment="0未审 1自动通过 2人工复核 3已拒绝")
    Violate_Record = db.Column(db.Text)
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)


class Task(db.Model):
    __tablename__ = "tasks"
    Task_ID = db.Column(db.String(32), primary_key=True)
    Task_Type = db.Column(db.String(20), nullable=False)
    Title = db.Column(db.String(100), nullable=False, default="")
    Description = db.Column(db.Text)
    Reward = db.Column(db.Float, default=0)
    Publisher_ID = db.Column(db.String(32), db.ForeignKey("users.User_ID"), nullable=False)
    Receiver_ID = db.Column(db.String(32), db.ForeignKey("users.User_ID"), nullable=True)
    Task_Location = db.Column(db.String(100), nullable=False, default="")
    Task_Status = db.Column(db.Integer, default=0, comment="-1驳回 0待审核 1待接单 2进行中 3已完成 4已取消")
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)
    AI_Category_Tag = db.Column(db.String(50))
    Escrow_Status = db.Column(db.Integer, default=0, comment="0未托管 1已托管 2已结算")

    publisher = db.relationship("User", foreign_keys=[Publisher_ID], backref="published")
    receiver = db.relationship("User", foreign_keys=[Receiver_ID], backref="accepted")


class Dispute(db.Model):
    __tablename__ = "disputes"
    Dispute_ID = db.Column(db.String(32), primary_key=True)
    Task_ID = db.Column(db.String(32), db.ForeignKey("tasks.Task_ID"), nullable=False)
    Initiator_ID = db.Column(db.String(32), db.ForeignKey("users.User_ID"), nullable=False)
    Reason = db.Column(db.Text, nullable=False)
    Status = db.Column(db.Integer, default=0, comment="0处理中 1已解决 2已驳回")
    Result = db.Column(db.Text)
    LLM_Summary = db.Column(db.Text)
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)


# ==========================================
# 管理后台面板页
# ==========================================

@app.route("/admin")
def admin_panel():
    return send_from_directory("static", "index.html")


# ==========================================
# 仪表盘统计
# ==========================================

@app.route("/admin/dashboard", methods=["GET"])
def dashboard():
    total_users = User.query.count()
    total_tasks = Task.query.count()
    pending_audit = Task.query.filter_by(Task_Status=0).count()
    active_tasks = Task.query.filter_by(Task_Status=2).count()
    completed_tasks = Task.query.filter_by(Task_Status=3).count()
    pending_users = User.query.filter_by(Auth_Status=0).count()
    disputes = Dispute.query.filter_by(Status=0).count()

    # 近7天每日任务量
    seven_days = datetime.utcnow() - timedelta(days=7)
    recent_tasks = (
        Task.query.filter(Task.Create_Time >= seven_days)
        .order_by(Task.Create_Time.desc())
        .all()
    )

    return jsonify({
        "code": 20000,
        "message": "success",
        "data": {
            "total_users": total_users,
            "total_tasks": total_tasks,
            "pending_audit": pending_audit,
            "active_tasks": active_tasks,
            "completed_tasks": completed_tasks,
            "pending_users": pending_users,
            "disputes": disputes,
        },
    })


# ==========================================
# 用户管理
# ==========================================

@app.route("/admin/users", methods=["GET"])
def list_users():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    status = request.args.get("auth_status", type=int)

    q = User.query
    if status is not None:
        q = q.filter_by(Auth_Status=status)

    pagination = q.order_by(User.Create_Time.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    users = [{
        "User_ID": u.User_ID,
        "Student_ID": u.Student_ID,
        "Name": u.Name,
        "Department": u.Department,
        "Phone": u.Phone[:3] + "****" + u.Phone[-4:] if len(u.Phone) >= 7 else u.Phone,
        "Credit_Score": u.Credit_Score,
        "Point_Balance": u.Point_Balance,
        "Auth_Status": u.Auth_Status,
        "Violate_Record": u.Violate_Record,
        "Create_Time": u.Create_Time.isoformat() if u.Create_Time else None,
    } for u in pagination.items]

    return jsonify({
        "code": 20000,
        "message": "success",
        "data": {"users": users, "total": pagination.total, "page": page},
    })


@app.route("/admin/users/<user_id>/audit", methods=["PUT"])
def audit_user(user_id):
    data = request.get_json()
    action = data.get("action")

    user = User.query.get(user_id)
    if not user:
        return jsonify({"code": 40400, "message": "用户不存在", "data": {}}), 404

    if action == "pass":
        user.Auth_Status = 1
        msg = "用户审核通过"
    elif action == "reject":
        user.Auth_Status = 3
        msg = "用户审核拒绝"
    elif action == "manual_review":
        user.Auth_Status = 2
        msg = "转入人工复核"
    else:
        return jsonify({"code": 40000, "message": "无效操作", "data": {}}), 400

    db.session.commit()
    return jsonify({"code": 20000, "message": msg, "data": {"User_ID": user.User_ID}})


@app.route("/admin/users/<user_id>/violate", methods=["PUT"])
def violate_user(user_id):
    data = request.get_json()
    reason = data.get("reason", "")
    penalty = data.get("penalty", 0)  # 扣分

    user = User.query.get(user_id)
    if not user:
        return jsonify({"code": 40400, "message": "用户不存在", "data": {}}), 404

    user.Credit_Score = max(0, user.Credit_Score - penalty)
    record = user.Violate_Record or ""
    user.Violate_Record = record + f"[{datetime.utcnow().isoformat()}] {reason}; "

    db.session.commit()
    return jsonify({
        "code": 20000,
        "message": "违规记录已更新",
        "data": {"User_ID": user.User_ID, "Credit_Score": user.Credit_Score},
    })


# ==========================================
# 任务管理
# ==========================================

@app.route("/admin/tasks", methods=["GET"])
def list_tasks():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)
    status = request.args.get("status", type=int)

    q = Task.query
    if status is not None:
        q = q.filter_by(Task_Status=status)

    pagination = q.order_by(Task.Create_Time.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    tasks = []
    for t in pagination.items:
        pub_name = t.publisher.Name if t.publisher else "未知"
        rec_name = t.receiver.Name if t.receiver else None
        tasks.append({
            "Task_ID": t.Task_ID,
            "Task_Type": t.Task_Type,
            "Title": t.Title,
            "Reward": t.Reward,
            "Publisher_Name": pub_name,
            "Receiver_Name": rec_name,
            "Task_Location": t.Task_Location,
            "Task_Status": t.Task_Status,
            "AI_Category_Tag": t.AI_Category_Tag,
            "Escrow_Status": t.Escrow_Status,
            "Create_Time": t.Create_Time.isoformat() if t.Create_Time else None,
        })

    return jsonify({
        "code": 20000,
        "message": "success",
        "data": {"tasks": tasks, "total": pagination.total, "page": page},
    })


@app.route("/admin/tasks/<task_id>/audit", methods=["PUT"])
def audit_task(task_id):
    data = request.get_json()
    action = data.get("action")

    task = Task.query.get(task_id)
    if not task:
        return jsonify({"code": 40400, "message": "任务不存在", "data": {}}), 404

    if action == "pass":
        task.Task_Status = 1
        msg = "审核通过，已上架"
    elif action == "reject":
        task.Task_Status = -1
        msg = "审核驳回"
    elif action == "ai_flag":
        task.Task_Status = 0
        task.AI_Category_Tag = "高风险/需人工复核"
        msg = "AI标记异常，转入人工复核"
    else:
        return jsonify({"code": 40000, "message": "无效的操作参数", "data": {}}), 400

    db.session.commit()
    return jsonify({
        "code": 20000,
        "message": msg,
        "data": {
            "Task_ID": task.Task_ID,
            "Task_Status": task.Task_Status,
            "AI_Category_Tag": task.AI_Category_Tag,
        },
    })


@app.route("/admin/tasks/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    task = Task.query.get(task_id)
    if not task:
        return jsonify({"code": 40400, "message": "任务不存在", "data": {}}), 404

    db.session.delete(task)
    db.session.commit()
    return jsonify({"code": 20000, "message": "任务已删除", "data": {}})


# ==========================================
# 纠纷管理
# ==========================================

@app.route("/admin/disputes", methods=["GET"])
def list_disputes():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 20, type=int)

    pagination = Dispute.query.order_by(Dispute.Create_Time.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    disputes = [{
        "Dispute_ID": d.Dispute_ID,
        "Task_ID": d.Task_ID,
        "Initiator_ID": d.Initiator_ID,
        "Reason": d.Reason,
        "Status": d.Status,
        "LLM_Summary": d.LLM_Summary,
        "Result": d.Result,
        "Create_Time": d.Create_Time.isoformat() if d.Create_Time else None,
    } for d in pagination.items]

    return jsonify({
        "code": 20000,
        "message": "success",
        "data": {"disputes": disputes, "total": pagination.total},
    })


@app.route("/admin/disputes/<dispute_id>/resolve", methods=["PUT"])
def resolve_dispute(dispute_id):
    data = request.get_json()
    dispute = Dispute.query.get(dispute_id)
    if not dispute:
        return jsonify({"code": 40400, "message": "纠纷不存在", "data": {}}), 404

    dispute.Status = 1
    dispute.Result = data.get("result", "")
    db.session.commit()
    return jsonify({"code": 20000, "message": "纠纷已处理", "data": {}})


if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(host="0.0.0.0", port=8081, debug=True)
