from models import db
from datetime import datetime


class Task(db.Model):
    __tablename__ = "tasks"

    Task_ID = db.Column(db.String(32), primary_key=True, comment="任务ID")
    Task_Type = db.Column(
        db.String(20),
        nullable=False,
        comment="任务类型: 跑腿代办/学习互助/技能服务",
    )
    Title = db.Column(db.String(100), nullable=False, comment="任务标题")
    Description = db.Column(db.Text, comment="任务描述")
    Reward = db.Column(db.Float, default=0, comment="报酬金额")
    Publisher_ID = db.Column(
        db.String(32), db.ForeignKey("users.User_ID"), nullable=False, comment="发布人ID"
    )
    Receiver_ID = db.Column(
        db.String(32), db.ForeignKey("users.User_ID"), nullable=True, comment="接单人ID"
    )
    Task_Location = db.Column(db.String(100), nullable=False, comment="任务位置")
    Location_Lng = db.Column(db.Float, comment="经度")
    Location_Lat = db.Column(db.Float, comment="纬度")
    Task_Status = db.Column(
        db.Integer,
        default=0,
        comment="状态: -1已驳回 0待审核 1待接单 2进行中 3已完成 4已取消",
    )
    Deadline = db.Column(db.DateTime, comment="截止时间")
    AI_Category_Tag = db.Column(db.String(50), comment="AI辅助分类标签")
    Escrow_Status = db.Column(
        db.Integer, default=0, comment="资金托管状态: 0未托管 1已托管 2已结算"
    )
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)
    Update_Time = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关联的消息
    messages = db.relationship(
        "Message", backref="task", lazy="dynamic", foreign_keys="Message.Task_ID"
    )
