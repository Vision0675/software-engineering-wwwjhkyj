from models import db


class User(db.Model):
    __tablename__ = "users"

    User_ID = db.Column(db.String(32), primary_key=True, comment="用户唯一ID")
    Student_ID = db.Column(
        db.String(20), unique=True, nullable=False, comment="学号"
    )
    Name = db.Column(db.String(50), nullable=False, comment="真实姓名")
    Department = db.Column(db.String(50), nullable=False, comment="院系")
    Phone = db.Column(db.String(11), nullable=False, comment="手机号")
    Avatar = db.Column(db.String(200), comment="头像URL")
    Credit_Score = db.Column(db.Integer, default=100, comment="信用分")
    Point_Balance = db.Column(db.Integer, default=0, comment="积分余额")
    Auth_Status = db.Column(
        db.Integer,
        default=0,
        comment="实名审核状态: 0未审 1自动通过 2人工复核 3已拒绝",
    )
    Violate_Record = db.Column(db.Text, comment="违规记录")
    OpenID = db.Column(db.String(64), unique=True, comment="微信OpenID")
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)

    # 关联关系
    published_tasks = db.relationship(
        "Task", foreign_keys="Task.Publisher_ID", backref="publisher", lazy="dynamic"
    )
    accepted_tasks = db.relationship(
        "Task", foreign_keys="Task.Receiver_ID", backref="receiver", lazy="dynamic"
    )
