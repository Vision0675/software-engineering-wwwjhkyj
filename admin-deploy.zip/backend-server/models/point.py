from models import db
from datetime import datetime


class PointLog(db.Model):
    __tablename__ = "point_logs"

    Log_ID = db.Column(db.String(32), primary_key=True, comment="日志ID")
    User_ID = db.Column(
        db.String(32), db.ForeignKey("users.User_ID"), nullable=False, comment="用户ID"
    )
    Change_Amount = db.Column(db.Integer, nullable=False, comment="变动数值")
    Reason = db.Column(db.String(100), nullable=False, comment="变动原因")
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)


class Dispute(db.Model):
    __tablename__ = "disputes"

    Dispute_ID = db.Column(db.String(32), primary_key=True, comment="纠纷ID")
    Task_ID = db.Column(
        db.String(32), db.ForeignKey("tasks.Task_ID"), nullable=False, comment="关联任务ID"
    )
    Initiator_ID = db.Column(
        db.String(32), db.ForeignKey("users.User_ID"), nullable=False, comment="发起人ID"
    )
    Reason = db.Column(db.Text, nullable=False, comment="纠纷原因")
    Status = db.Column(
        db.Integer, default=0, comment="状态: 0处理中 1已解决 2已驳回"
    )
    Result = db.Column(db.Text, comment="处理结果")
    LLM_Summary = db.Column(db.Text, comment="LLM生成的争议摘要")
    Create_Time = db.Column(db.DateTime, default=datetime.utcnow)
    Resolve_Time = db.Column(db.DateTime)
