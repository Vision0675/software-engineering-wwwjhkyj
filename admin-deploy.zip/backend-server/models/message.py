from models import db
from datetime import datetime


class Message(db.Model):
    __tablename__ = "messages"

    Msg_ID = db.Column(db.String(32), primary_key=True, comment="消息ID")
    Task_ID = db.Column(
        db.String(32), db.ForeignKey("tasks.Task_ID"), nullable=False, comment="关联任务ID"
    )
    Sender_ID = db.Column(
        db.String(32), db.ForeignKey("users.User_ID"), nullable=False, comment="发送人ID"
    )
    Content = db.Column(db.Text, nullable=False, comment="消息内容")
    Msg_Type = db.Column(
        db.Integer, default=0, comment="消息类型: 0文字 1图片 2系统通知"
    )
    Send_Time = db.Column(db.DateTime, default=datetime.utcnow)
