import jwt
import datetime
from functools import wraps
from flask import request, current_app

from utils.response import unauthorized


def generate_token(user_id):
    payload = {
        "user_id": user_id,
        "exp": datetime.datetime.utcnow()
        + datetime.timedelta(hours=current_app.config.get("JWT_EXPIRATION_HOURS", 72)),
        "iat": datetime.datetime.utcnow(),
    }
    return jwt.encode(payload, current_app.config["SECRET_KEY"], algorithm="HS256")


def decode_token(token):
    return jwt.decode(token, current_app.config["SECRET_KEY"], algorithms=["HS256"])


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            return unauthorized("缺少认证令牌")

        token = header[7:]
        try:
            payload = decode_token(token)
            request.current_user_id = payload["user_id"]
        except jwt.ExpiredSignatureError:
            return unauthorized("令牌已过期")
        except jwt.InvalidTokenError:
            return unauthorized("无效的令牌")

        return f(*args, **kwargs)

    return decorated
