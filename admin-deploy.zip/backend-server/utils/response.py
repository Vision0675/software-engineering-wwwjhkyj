from flask import jsonify


def ok(data=None, message="success"):
    return jsonify({"code": 20000, "message": message, "data": data or {}})


def fail(code=40000, message="error", data=None):
    return jsonify({"code": code, "message": message, "data": data or {}}), 400


def not_found(message="资源不存在"):
    return jsonify({"code": 40400, "message": message, "data": {}}), 404


def unauthorized(message="未授权的访问"):
    return jsonify({"code": 40100, "message": message, "data": {}}), 401


def server_error(message="服务器内部错误"):
    return jsonify({"code": 50000, "message": message, "data": {}}), 500
