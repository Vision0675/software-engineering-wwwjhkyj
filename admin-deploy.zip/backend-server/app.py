import os
from flask import Flask
from flask_cors import CORS
from flask_socketio import SocketIO

from config import config_by_name
from models import db
from routes.auth import auth_bp
from routes.task import task_bp
from routes.message import message_bp
from routes.map import map_bp
from websocket.chat import register_socketio_handlers


def create_app(config_name=None):
    if config_name is None:
        config_name = os.getenv("FLASK_ENV", "development")

    app = Flask(__name__)
    app.config.from_object(config_by_name[config_name])

    CORS(app)
    db.init_app(app)

    app.register_blueprint(auth_bp, url_prefix="/api/v1")
    app.register_blueprint(task_bp, url_prefix="/api/v1")
    app.register_blueprint(message_bp, url_prefix="/api/v1")
    app.register_blueprint(map_bp, url_prefix="/api/v1")

    with app.app_context():
        db.create_all()

    return app


def create_socketio_app():
    app = create_app()
    socketio = SocketIO(
        app,
        cors_allowed_origins="*",
        async_mode="gevent",
        logger=False,
        engineio_logger=False,
    )
    register_socketio_handlers(socketio)
    return socketio, app


socketio, app = create_socketio_app()

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=8080, debug=True)
