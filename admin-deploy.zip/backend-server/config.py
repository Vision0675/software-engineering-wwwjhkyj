import os


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "gongji-campus-secret-key-2026")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DB_URI",
        "sqlite:///campus_task.db",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_EXPIRATION_HOURS = 72


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
}
