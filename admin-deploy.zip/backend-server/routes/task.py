import uuid
from datetime import datetime
from flask import Blueprint, request
from models import db
from models.task import Task
from models.user import User
from utils.response import ok, fail, not_found
from utils.auth import login_required

task_bp = Blueprint("task", __name__)


@task_bp.route("/tasks", methods=["POST"])
@login_required
def create_task():
    data = request.get_json()

    required_fields = ["Task_Type", "Title", "Task_Location"]
    for f in required_fields:
        if f not in data:
            return fail(40000, f"缺少必填字段: {f}")

    task = Task(
        Task_ID=f"T_{uuid.uuid4().hex[:12]}",
        Task_Type=data["Task_Type"],
        Title=data["Title"],
        Description=data.get("Description", ""),
        Reward=data.get("Reward", 0),
        Publisher_ID=request.current_user_id,
        Task_Location=data["Task_Location"],
        Location_Lng=data.get("Location_Lng"),
        Location_Lat=data.get("Location_Lat"),
        Task_Status=0,  # 待审核
        Deadline=(
            datetime.fromisoformat(data["Deadline"])
            if data.get("Deadline")
            else None
        ),
    )
    db.session.add(task)
    db.session.commit()

    return ok(
        {
            "Task_ID": task.Task_ID,
            "Task_Status": task.Task_Status,
            "Create_Time": task.Create_Time.isoformat(),
        }
    )


@task_bp.route("/tasks", methods=["GET"])
def list_tasks():
    page = request.args.get("page", 1, type=int)
    per_page = request.args.get("per_page", 10, type=int)
    task_type = request.args.get("type")
    status = request.args.get("status", 1, type=int)  # 默认查询待接单

    q = Task.query.filter_by(Task_Status=status)
    if task_type:
        q = q.filter_by(Task_Type=task_type)

    pagination = q.order_by(Task.Create_Time.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )

    tasks = []
    for t in pagination.items:
        publisher = User.query.get(t.Publisher_ID)
        tasks.append(
            {
                "Task_ID": t.Task_ID,
                "Task_Type": t.Task_Type,
                "Title": t.Title,
                "Description": t.Description,
                "Reward": t.Reward,
                "Publisher_Name": publisher.Name if publisher else "未知",
                "Publisher_Avatar": publisher.Avatar if publisher else None,
                "Task_Location": t.Task_Location,
                "Location_Lng": t.Location_Lng,
                "Location_Lat": t.Location_Lat,
                "Task_Status": t.Task_Status,
                "Deadline": t.Deadline.isoformat() if t.Deadline else None,
                "Create_Time": t.Create_Time.isoformat(),
            }
        )

    return ok(
        {
            "tasks": tasks,
            "total": pagination.total,
            "page": page,
            "per_page": per_page,
        }
    )


@task_bp.route("/tasks/<task_id>", methods=["GET"])
def get_task(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    publisher = User.query.get(task.Publisher_ID)
    receiver = User.query.get(task.Receiver_ID) if task.Receiver_ID else None

    return ok(
        {
            "Task_ID": task.Task_ID,
            "Task_Type": task.Task_Type,
            "Title": task.Title,
            "Description": task.Description,
            "Reward": task.Reward,
            "Publisher_ID": task.Publisher_ID,
            "Publisher_Name": publisher.Name if publisher else "未知",
            "Publisher_Avatar": publisher.Avatar if publisher else None,
            "Receiver_ID": task.Receiver_ID,
            "Receiver_Name": receiver.Name if receiver else None,
            "Task_Location": task.Task_Location,
            "Location_Lng": task.Location_Lng,
            "Location_Lat": task.Location_Lat,
            "Task_Status": task.Task_Status,
            "AI_Category_Tag": task.AI_Category_Tag,
            "Escrow_Status": task.Escrow_Status,
            "Deadline": task.Deadline.isoformat() if task.Deadline else None,
            "Create_Time": task.Create_Time.isoformat(),
        }
    )


@task_bp.route("/tasks/<task_id>/accept", methods=["POST"])
@login_required
def accept_task(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    if task.Task_Status != 1:
        return fail(40000, "该任务当前不可接单")

    if task.Publisher_ID == request.current_user_id:
        return fail(40000, "不能接自己发布的任务")

    task.Receiver_ID = request.current_user_id
    task.Task_Status = 2  # 进行中
    db.session.commit()

    return ok({"Task_ID": task.Task_ID, "Task_Status": task.Task_Status})


@task_bp.route("/tasks/<task_id>/complete", methods=["POST"])
@login_required
def complete_task(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    if task.Task_Status != 2:
        return fail(40000, "该任务非进行中状态")

    if task.Publisher_ID != request.current_user_id:
        return fail(40000, "仅发布人可确认完成")

    task.Task_Status = 3  # 已完成
    db.session.commit()

    return ok({"Task_ID": task.Task_ID, "Task_Status": task.Task_Status})


@task_bp.route("/tasks/<task_id>/cancel", methods=["POST"])
@login_required
def cancel_task(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    if task.Publisher_ID != request.current_user_id:
        return fail(40000, "仅发布人可取消")

    if task.Task_Status not in [0, 1]:
        return fail(40000, "当前状态不可取消")

    task.Task_Status = 4
    db.session.commit()

    return ok({"Task_ID": task.Task_ID, "Task_Status": task.Task_Status})


@task_bp.route("/user/tasks/published", methods=["GET"])
@login_required
def my_published_tasks():
    tasks = (
        Task.query.filter_by(Publisher_ID=request.current_user_id)
        .order_by(Task.Create_Time.desc())
        .limit(50)
        .all()
    )
    return ok({"tasks": [_task_brief(t) for t in tasks]})


@task_bp.route("/user/tasks/accepted", methods=["GET"])
@login_required
def my_accepted_tasks():
    tasks = (
        Task.query.filter_by(Receiver_ID=request.current_user_id)
        .order_by(Task.Create_Time.desc())
        .limit(50)
        .all()
    )
    return ok({"tasks": [_task_brief(t) for t in tasks]})


def _task_brief(t):
    return {
        "Task_ID": t.Task_ID,
        "Task_Type": t.Task_Type,
        "Title": t.Title,
        "Reward": t.Reward,
        "Task_Location": t.Task_Location,
        "Task_Status": t.Task_Status,
        "Create_Time": t.Create_Time.isoformat(),
    }
