import uuid
from flask import Blueprint, request
from models import db
from models.user import User
from utils.response import ok, fail
from utils.auth import generate_token, login_required

auth_bp = Blueprint("auth", __name__)


@auth_bp.route("/auth/register", methods=["POST"])
def register():
    data = request.get_json()
    student_id = data.get("Student_ID")
    name = data.get("Name")
    department = data.get("Department")
    phone = data.get("Phone")
    openid = data.get("OpenID")

    if not all([student_id, name, department, phone]):
        return fail(40000, "必填字段缺失: Student_ID, Name, Department, Phone")

    if User.query.filter_by(Student_ID=student_id).first():
        return fail(40000, "该学号已注册")

    if openid and User.query.filter_by(OpenID=openid).first():
        return fail(40000, "该微信账号已绑定")

    user = User(
        User_ID=f"U_{uuid.uuid4().hex[:12]}",
        Student_ID=student_id,
        Name=name,
        Department=department,
        Phone=phone,
        OpenID=openid,
        Auth_Status=0,
    )
    db.session.add(user)
    db.session.commit()

    token = generate_token(user.User_ID)
    return ok({"token": token, "User_ID": user.User_ID, "Auth_Status": user.Auth_Status})


@auth_bp.route("/auth/login", methods=["POST"])
def login():
    data = request.get_json()
    openid = data.get("OpenID")

    if not openid:
        return fail(40000, "缺少OpenID")

    user = User.query.filter_by(OpenID=openid).first()
    if not user:
        return fail(40000, "未注册，请先完成注册")

    token = generate_token(user.User_ID)
    return ok(
        {
            "token": token,
            "User_ID": user.User_ID,
            "Name": user.Name,
            "Auth_Status": user.Auth_Status,
            "Credit_Score": user.Credit_Score,
        }
    )


@auth_bp.route("/user/profile", methods=["GET"])
@login_required
def get_profile():
    user = User.query.get(request.current_user_id)
    if not user:
        return fail(40400, "用户不存在")

    return ok(
        {
            "User_ID": user.User_ID,
            "Student_ID": user.Student_ID,
            "Name": user.Name,
            "Department": user.Department,
            "Phone": user.Phone[:3] + "****" + user.Phone[-4:],  # 脱敏
            "Avatar": user.Avatar,
            "Credit_Score": user.Credit_Score,
            "Point_Balance": user.Point_Balance,
            "Auth_Status": user.Auth_Status,
        }
    )


@auth_bp.route("/user/profile", methods=["PUT"])
@login_required
def update_profile():
    user = User.query.get(request.current_user_id)
    data = request.get_json()

    if "Avatar" in data:
        user.Avatar = data["Avatar"]
    if "Phone" in data:
        user.Phone = data["Phone"]

    db.session.commit()
    return ok({"User_ID": user.User_ID})
