import uuid
from flask import Blueprint, request
from models import db
from models.message import Message
from models.task import Task
from utils.response import ok, fail, not_found
from utils.auth import login_required

message_bp = Blueprint("message", __name__)


@message_bp.route("/tasks/<task_id>/messages", methods=["GET"])
@login_required
def get_messages(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    user_id = request.current_user_id
    if user_id not in [task.Publisher_ID, task.Receiver_ID]:
        return fail(40300, "无权查看该任务的聊天记录")

    messages = (
        Message.query.filter_by(Task_ID=task_id)
        .order_by(Message.Send_Time.asc())
        .limit(100)
        .all()
    )

    return ok(
        {
            "messages": [
                {
                    "Msg_ID": m.Msg_ID,
                    "Sender_ID": m.Sender_ID,
                    "Content": m.Content,
                    "Msg_Type": m.Msg_Type,
                    "Send_Time": m.Send_Time.isoformat(),
                }
                for m in messages
            ]
        }
    )


@message_bp.route("/tasks/<task_id>/messages", methods=["POST"])
@login_required
def send_message(task_id):
    task = Task.query.get(task_id)
    if not task:
        return not_found("任务不存在")

    user_id = request.current_user_id
    if user_id not in [task.Publisher_ID, task.Receiver_ID]:
        return fail(40300, "无权发送消息")

    data = request.get_json()
    content = data.get("Content", "").strip()
    if not content:
        return fail(40000, "消息内容不能为空")

    msg = Message(
        Msg_ID=f"M_{uuid.uuid4().hex[:12]}",
        Task_ID=task_id,
        Sender_ID=user_id,
        Content=content,
        Msg_Type=data.get("Msg_Type", 0),
    )
    db.session.add(msg)
    db.session.commit()

    return ok(
        {
            "Msg_ID": msg.Msg_ID,
            "Sender_ID": msg.Sender_ID,
            "Content": msg.Content,
            "Send_Time": msg.Send_Time.isoformat(),
        }
    )
