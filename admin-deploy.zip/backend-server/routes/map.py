from math import radians, sin, cos, sqrt, atan2
from flask import Blueprint, request
from models.task import Task
from utils.response import ok

map_bp = Blueprint("map", __name__)


@map_bp.route("/map/tasks/nearby", methods=["GET"])
def nearby_tasks():
    try:
        lng = float(request.args.get("lng", 0))
        lat = float(request.args.get("lat", 0))
    except (TypeError, ValueError):
        return ok({"tasks": []})

    radius = request.args.get("radius", 3000, type=int)  # 默认3km

    tasks = Task.query.filter(
        Task.Task_Status == 1,
        Task.Location_Lng.isnot(None),
        Task.Location_Lat.isnot(None),
    ).all()

    nearby = []
    for t in tasks:
        dist = _haversine(lng, lat, t.Location_Lng, t.Location_Lat)
        if dist <= radius:
            nearby.append(
                {
                    "Task_ID": t.Task_ID,
                    "Title": t.Title,
                    "Task_Type": t.Task_Type,
                    "Reward": t.Reward,
                    "Task_Location": t.Task_Location,
                    "Location_Lng": t.Location_Lng,
                    "Location_Lat": t.Location_Lat,
                    "Distance": round(dist, 0),
                }
            )

    nearby.sort(key=lambda x: x["Distance"])
    return ok({"tasks": nearby})


def _haversine(lng1, lat1, lng2, lat2):
    R = 6371000  # 地球半径（米）
    dlat = radians(lat2 - lat1)
    dlng = radians(lng2 - lng1)
    a = (
        sin(dlat / 2) ** 2
        + cos(radians(lat1)) * cos(radians(lat2)) * sin(dlng / 2) ** 2
    )
    return R * 2 * atan2(sqrt(a), sqrt(1 - a))
