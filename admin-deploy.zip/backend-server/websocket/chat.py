import uuid
from flask import request
from flask_socketio import emit, join_room, leave_room
from models import db
from models.message import Message
from models.task import Task


def register_socketio_handlers(socketio):
    @socketio.on("connect")
    def handle_connect():
        user_id = request.args.get("user_id")
        if user_id:
            join_room(f"user_{user_id}")

    @socketio.on("join_task")
    def handle_join_task(data):
        task_id = data.get("task_id")
        if task_id:
            join_room(f"task_{task_id}")

    @socketio.on("send_message")
    def handle_send_message(data):
        task_id = data.get("task_id")
        sender_id = data.get("sender_id")
        content = data.get("content", "").strip()
        msg_type = data.get("msg_type", 0)

        if not all([task_id, sender_id, content]):
            emit("error", {"message": "缺少必要参数"})
            return

        task = Task.query.get(task_id)
        if not task:
            emit("error", {"message": "任务不存在"})
            return

        if sender_id not in [task.Publisher_ID, task.Receiver_ID]:
            emit("error", {"message": "无权发送消息"})
            return

        msg = Message(
            Msg_ID=f"M_{uuid.uuid4().hex[:12]}",
            Task_ID=task_id,
            Sender_ID=sender_id,
            Content=content,
            Msg_Type=msg_type,
        )
        db.session.add(msg)
        db.session.commit()

        payload = {
            "Msg_ID": msg.Msg_ID,
            "Task_ID": task_id,
            "Sender_ID": sender_id,
            "Content": content,
            "Msg_Type": msg_type,
            "Send_Time": msg.Send_Time.isoformat(),
        }
        emit("new_message", payload, room=f"task_{task_id}")

    @socketio.on("leave_task")
    def handle_leave_task(data):
        task_id = data.get("task_id")
        if task_id:
            leave_room(f"task_{task_id}")

    @socketio.on("disconnect")
    def handle_disconnect():
        pass
