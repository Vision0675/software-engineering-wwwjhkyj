App({
  onLaunch() {
    // 初始化云开发（已填入你的环境ID）
    wx.cloud.init({
      env: 'cloud1-d7gmiwp417137c6a6',
      traceUser: true
    });

    // 先尝试获取openid，不获取用户信息
    this.tryGetOpenid();
  },

  // 带重试机制的云函数调用
  async callFunctionWithRetry(options, maxRetries = 2) {
    let retries = 0;
    while (retries <= maxRetries) {
      try {
        return await wx.cloud.callFunction({
          ...options,
          timeout: 20000 // 延长到20秒超时
        });
      } catch (err) {
        retries++;
        if (retries > maxRetries) {
          throw err;
        }
        console.log(`云函数调用失败，正在重试第${retries}次...`);
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }
  },

  // 只获取openid，不获取用户信息
  async tryGetOpenid() {
    try {
      // 1. 调用云函数获取openid（带重试）
      const { result } = await this.callFunctionWithRetry({
        name: 'getOpenid'
      });
      const openid = result.openid;
      this.globalData.openid = openid;
      console.log('成功获取openid:', openid);

      // 2. 尝试从数据库获取用户信息
      const db = wx.cloud.database();
      const res = await db.collection('users').doc(openid).get();
      
      // 如果能走到这里，说明用户已注册
      this.globalData.userInfo = res.data;
      this.globalData.isLoggedIn = true;
      console.log('用户已登录', res.data);

    } catch (err) {
      // 错误处理：区分不同情况
      if (err.errCode === -1 || err.errMsg.includes('cannot find document')) {
        // 这是正常情况：用户未注册
        console.log('用户未注册，需要手动登录');
        this.globalData.isLoggedIn = false;
      } else if (err.errMsg.includes('timeout')) {
        // 超时错误
        console.error('云函数调用超时', err);
        this.globalData.isLoggedIn = false;
        wx.showToast({
          title: '网络较慢，请稍后重试',
          icon: 'none',
          duration: 3000
        });
      } else {
        // 其他错误
        console.error('获取用户信息失败', err);
        this.globalData.isLoggedIn = false;
        wx.showToast({
          title: '网络连接异常',
          icon: 'none',
          duration: 2000
        });
      }
    }
  },

  // 用户点击登录按钮后调用这个方法
  async loginUser(callback) {
    try {
      wx.showLoading({
        title: '登录中...'
      });

      // 1. 获取用户信息（必须由用户点击触发）
      const userInfoRes = await wx.getUserProfile({
        desc: '用于完善校圈用户资料'
      });
      const userInfo = userInfoRes.userInfo;

      // 2. 生成唯一校圈ID（带重试）
      const { result } = await this.callFunctionWithRetry({
        name: 'generateSchoolId'
      });
      const schoolId = result.schoolId;

      // 3. 保存到数据库
      const db = wx.cloud.database();
      await db.collection('users').doc(this.globalData.openid).set({
        data: {
          schoolId: schoolId,
          nickname: userInfo.nickName,
          avatar: userInfo.avatarUrl,
          signature: '这个人很懒，什么都没写',
          createTime: db.serverDate()
        }
      });

      // 4. 保存到全局数据
      this.globalData.userInfo = {
        _id: this.globalData.openid,
        schoolId: schoolId,
        nickname: userInfo.nickName,
        avatar: userInfo.avatarUrl,
        signature: '这个人很懒，什么都没写'
      };
      this.globalData.isLoggedIn = true;

      wx.hideLoading();
      wx.showToast({
        title: `注册成功！你的校圈ID：${schoolId}`,
        icon: 'none',
        duration: 3000
      });

      // 回调函数，通知页面登录成功
      if (callback) callback(true);

    } catch (err) {
      wx.hideLoading();
      console.error('登录失败', err);
      
      if (err.errMsg.includes('timeout')) {
        wx.showToast({
          title: '网络较慢，请稍后重试',
          icon: 'none',
          duration: 3000
        });
      } else {
        wx.showToast({
          title: '登录失败，请重试',
          icon: 'none'
        });
      }
      
      if (callback) callback(false);
    }
  },

  globalData: {
    openid: null,
    userInfo: null,
    isLoggedIn: false // 登录状态
  }
});