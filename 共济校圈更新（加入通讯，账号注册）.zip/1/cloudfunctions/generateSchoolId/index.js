const cloud = require('wx-server-sdk');
cloud.init({
  env: 'cloud1-d7gmiwp417137c6a6'
});
const db = cloud.database();

// 生成6位随机数字ID
function generateRandomId() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

exports.main = async (event, context) => {
  let schoolId;
  let isUnique = false;

  // 循环生成直到找到唯一ID
  while (!isUnique) {
    schoolId = generateRandomId();
    const res = await db.collection('users')
      .where({ schoolId: schoolId })
      .count();
    
    if (res.total === 0) {
      isUnique = true;
    }
  }

  return {
    schoolId: schoolId
  };
};