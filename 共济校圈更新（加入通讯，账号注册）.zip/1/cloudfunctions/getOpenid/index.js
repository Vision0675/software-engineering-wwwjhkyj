const cloud = require('wx-server-sdk');
cloud.init({
  env: 'cloud1-d7gmiwp417137c6a6'
});

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  return {
    openid: wxContext.OPENID
  };
};