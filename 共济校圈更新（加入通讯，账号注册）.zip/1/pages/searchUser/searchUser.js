const app = getApp();

Page({
  data: {
    searchId: '',
    searchResult: null,
    isFriend: false,
    isRequestSent: false,
    showEmptyTip: false
  },

  // 监听输入
  onInput(e) {
    this.setData({
      searchId: e.detail.value,
      searchResult: null,
      showEmptyTip: false
    });
  },

  // 搜索用户
  async searchUser() {
    const schoolId = this.data.searchId.trim();
    
    if (!schoolId) {
      wx.showToast({
        title: '请输入校圈ID',
        icon: 'none'
      });
      return;
    }

    if (schoolId.length !== 6) {
      wx.showToast({
        title: '校圈ID必须是6位数字',
        icon: 'none'
      });
      return;
    }

    wx.showLoading({
      title: '搜索中...'
    });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('users')
        .where({ schoolId: schoolId })
        .get();

      wx.hideLoading();

      if (res.data.length === 0) {
        this.setData({
          showEmptyTip: true
        });
        return;
      }

      const user = res.data[0];
      
      // 不能加自己
      if (user._id === app.globalData.openid) {
        wx.showToast({
          title: '不能添加自己为好友',
          icon: 'none'
        });
        return;
      }

      // 检查是否已是好友
      const friendRes = await db.collection('friends')
        .where({
          userId: app.globalData.openid,
          friendId: user._id
        })
        .count();

      // 检查是否已发送申请
      const requestRes = await db.collection('friendRequests')
        .where({
          fromUserId: app.globalData.openid,
          toUserId: user._id,
          status: 0 // 0表示待处理
        })
        .count();

      this.setData({
        searchResult: user,
        isFriend: friendRes.total > 0,
        isRequestSent: requestRes.total > 0
      });

    } catch (err) {
      wx.hideLoading();
      console.error('搜索失败', err);
      wx.showToast({
        title: '搜索失败，请重试',
        icon: 'none'
      });
    }
  },

  // 发送好友申请
  async sendFriendRequest() {
    wx.showLoading({
      title: '发送中...'
    });

    try {
      const db = wx.cloud.database();
      await db.collection('friendRequests').add({
        data: {
          fromUserId: app.globalData.openid,
          fromUserInfo: app.globalData.userInfo,
          toUserId: this.data.searchResult._id,
          toUserInfo: this.data.searchResult,
          status: 0, // 0待处理 1已同意 2已拒绝
          createTime: db.serverDate()
        }
      });

      wx.hideLoading();
      this.setData({
        isRequestSent: true
      });

      wx.showToast({
        title: '好友申请已发送',
        icon: 'success'
      });

    } catch (err) {
      wx.hideLoading();
      console.error('发送申请失败', err);
      wx.showToast({
        title: '发送失败，请重试',
        icon: 'none'
      });
    }
  }
});