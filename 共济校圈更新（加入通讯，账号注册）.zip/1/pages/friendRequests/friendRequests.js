const app = getApp();

Page({
  data: {
    requestList: []
  },

  onShow() {
    this.getFriendRequests();
  },

  // 获取好友申请列表
  async getFriendRequests() {
    wx.showLoading({
      title: '加载中...'
    });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('friendRequests')
        .where({
          toUserId: app.globalData.openid
        })
        .orderBy('createTime', 'desc')
        .get();

      wx.hideLoading();
      this.setData({
        requestList: res.data
      });

    } catch (err) {
      wx.hideLoading();
      console.error('获取申请列表失败', err);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    }
  },

  // 同意好友申请
  async acceptRequest(e) {
    const requestId = e.currentTarget.dataset.id;
    const requestItem = e.currentTarget.dataset.item;

    wx.showLoading({
      title: '处理中...'
    });

    try {
      const db = wx.cloud.database();
      
      // 1. 更新申请状态为已同意
      await db.collection('friendRequests').doc(requestId).update({
        data: {
          status: 1
        }
      });

      // 2. 给我添加这个好友
      await db.collection('friends').add({
        data: {
          userId: app.globalData.openid,
          friendId: requestItem.fromUserId,
          friendNickname: requestItem.fromUserInfo.nickname,
          friendAvatar: requestItem.fromUserInfo.avatar,
          friendSchoolId: requestItem.fromUserInfo.schoolId,
          createTime: db.serverDate()
        }
      });

      // 3. 给对方也添加我为好友
      await db.collection('friends').add({
        data: {
          userId: requestItem.fromUserId,
          friendId: app.globalData.openid,
          friendNickname: app.globalData.userInfo.nickname,
          friendAvatar: app.globalData.userInfo.avatar,
          friendSchoolId: app.globalData.userInfo.schoolId,
          createTime: db.serverDate()
        }
      });

      wx.hideLoading();
      wx.showToast({
        title: '已添加为好友',
        icon: 'success'
      });

      // 刷新列表
      this.getFriendRequests();

    } catch (err) {
      wx.hideLoading();
      console.error('同意申请失败', err);
      wx.showToast({
        title: '处理失败，请重试',
        icon: 'none'
      });
    }
  },

  // 拒绝好友申请
  async rejectRequest(e) {
    const requestId = e.currentTarget.dataset.id;

    wx.showLoading({
      title: '处理中...'
    });

    try {
      const db = wx.cloud.database();
      await db.collection('friendRequests').doc(requestId).update({
        data: {
          status: 2
        }
      });

      wx.hideLoading();
      wx.showToast({
        title: '已拒绝',
        icon: 'success'
      });

      // 刷新列表
      this.getFriendRequests();

    } catch (err) {
      wx.hideLoading();
      console.error('拒绝申请失败', err);
      wx.showToast({
        title: '处理失败，请重试',
        icon: 'none'
      });
    }
  }
});