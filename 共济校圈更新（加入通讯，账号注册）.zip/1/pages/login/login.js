const app = getApp();

Page({
  // 处理登录
  async handleLogin() {
    wx.showLoading({
      title: '登录中...'
    });

    await app.loginUser((success) => {
      wx.hideLoading();
      if (success) {
        // 登录成功，跳转到首页
        wx.switchTab({
          url: '/pages/index/index'
        });
      }
    });
  }
});