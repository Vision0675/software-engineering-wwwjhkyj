const app = getApp();

Page({
  data: {
    userInfo: {},
    pendingRequestsCount: 0,
    isLoggedIn: false
  },

  onShow() {
    this.checkLoginStatus();
  },

  // 检查登录状态
  checkLoginStatus() {
    if (app.globalData.isLoggedIn) {
      this.setData({
        isLoggedIn: true,
        userInfo: app.globalData.userInfo
      });
      this.getPendingRequestsCount();
    } else {
      this.setData({
        isLoggedIn: false
      });
    }
  },

  // 跳转到登录页面
  goToLogin() {
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  // 获取待处理好友申请数量
  async getPendingRequestsCount() {
    try {
      const db = wx.cloud.database();
      const res = await db.collection('friendRequests')
        .where({
          toUserId: app.globalData.openid,
          status: 0
        })
        .count();
      
      this.setData({
        pendingRequestsCount: res.total
      });
    } catch (err) {
      console.error('获取申请数量失败', err);
    }
  },

  // 编辑资料
  editProfile() {
    wx.showToast({
      title: '编辑资料功能开发中',
      icon: 'none'
    });
  },

  // 查看好友申请
  viewFriendRequests() {
    if (!app.globalData.isLoggedIn) {
      this.goToLogin();
      return;
    }
    wx.navigateTo({
      url: '/pages/friendRequests/friendRequests'
    });
  },

  // 查看我的好友
  viewFriends() {
    if (!app.globalData.isLoggedIn) {
      this.goToLogin();
      return;
    }
    wx.navigateTo({
      url: '/pages/friends/friends'
    });
  },

  // 关于我们
  aboutUs() {
    wx.showModal({
      title: '关于共济校圈',
      content: '共济校圈是专为大学生打造的校园生活服务平台，提供校园地图、即时通讯、动态分享等功能。',
      showCancel: false,
      confirmText: '知道了'
    });
  }
});