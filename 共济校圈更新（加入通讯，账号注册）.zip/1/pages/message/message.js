Page({
  // 跳转到搜索用户页面
  goToSearchUser() {
    wx.navigateTo({
      url: '/pages/searchUser/searchUser'
    });
  }
});