const app = getApp();

Page({
  data: {
    friendList: []
  },

  onShow() {
    this.getFriendList();
  },

  // 获取好友列表
  async getFriendList() {
    wx.showLoading({
      title: '加载中...'
    });

    try {
      const db = wx.cloud.database();
      const res = await db.collection('friends')
        .where({
          userId: app.globalData.openid
        })
        .orderBy('createTime', 'desc')
        .get();

      wx.hideLoading();
      this.setData({
        friendList: res.data
      });

    } catch (err) {
      wx.hideLoading();
      console.error('获取好友列表失败', err);
      wx.showToast({
        title: '加载失败，请重试',
        icon: 'none'
      });
    }
  },

  // 跳转到聊天页面（我们下节课实现）
  goToChat(e) {
    const friend = e.currentTarget.dataset.friend;
    wx.showToast({
      title: '聊天功能开发中',
      icon: 'none'
    });
  }
});