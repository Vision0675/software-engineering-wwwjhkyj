const api = require('../../utils/api')

Page({
  data: {
    tasks: [],
    activeType: '',
    page: 1,
    hasMore: true,
    loading: false
  },

  onLoad() {
    this.loadTasks()
  },

  onShow() {
    if (this.data.tasks.length === 0) {
      this.loadTasks()
    }
  },

  onPullDownRefresh() {
    this.setData({ page: 1, tasks: [], hasMore: true })
    this.loadTasks().finally(() => wx.stopPullDownRefresh())
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadTasks()
    }
  },

  loadTasks() {
    if (this.data.loading) return
    this.setData({ loading: true })

    const { activeType, page } = this.data
    const params = { page, per_page: 10 }
    if (activeType) params.type = activeType

    return api.get('/tasks', params)
      .then(data => {
        this.setData({
          tasks: page === 1 ? data.tasks : this.data.tasks.concat(data.tasks),
          hasMore: data.tasks.length === 10,
          page: page + 1,
          loading: false
        })
      })
      .catch(() => this.setData({ loading: false }))
  },

  switchType(e) {
    const type = e.currentTarget.dataset.type
    this.setData({
      activeType: this.data.activeType === type ? '' : type,
      page: 1,
      tasks: [],
      hasMore: true
    })
    this.loadTasks()
  },

  goToDetail(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/task-detail/task-detail?id=${id}` })
  },

  goToPublish() {
    const app = getApp()
    if (!app.checkLogin()) return
    wx.navigateTo({ url: '/pages/publish/publish' })
  }
})
