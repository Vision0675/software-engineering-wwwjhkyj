const api = require('../../utils/api')

Page({
  data: {
    centerLongitude: 121.490317,
    centerLatitude: 31.289133,
    mapScale: 17,
    markers: [],
    polyline: [],
    searchKeyword: '',
    showPoiPopup: false,
    currentPoi: {},
    isLoading: true
  },

  onLoad() {
    this.loadCampusPOIs()
    this.loadNearbyTasks()

    setTimeout(() => {
      this.setData({ isLoading: false })
    }, 1000)
  },

  loadCampusPOIs() {
    const campusPOIs = [
      {
        id: 1,
        title: '第一教学楼',
        address: '共济大学第一教学楼',
        longitude: 121.490317,
        latitude: 31.289133,
        iconPath: 'https://img.icons8.com/color/48/0066ff/school-building.png',
        width: 40,
        height: 40,
        isTask: false
      },
      {
        id: 2,
        title: '图书馆',
        address: '共济大学图书馆',
        longitude: 121.488500,
        latitude: 31.287800,
        iconPath: 'https://img.icons8.com/color/48/0066ff/library.png',
        width: 40,
        height: 40,
        isTask: false
      },
      {
        id: 3,
        title: '学生一食堂',
        address: '共济大学第一食堂',
        longitude: 121.492000,
        latitude: 31.290500,
        iconPath: 'https://img.icons8.com/color/48/0066ff/restaurant.png',
        width: 40,
        height: 40,
        isTask: false
      },
      {
        id: 4,
        title: '学生宿舍3号楼',
        address: '共济大学学生宿舍区3号楼',
        longitude: 121.493500,
        latitude: 31.291200,
        iconPath: 'https://img.icons8.com/color/48/0066ff/home.png',
        width: 40,
        height: 40,
        isTask: false
      },
      {
        id: 5,
        title: '菜鸟驿站',
        address: '共济大学快递服务中心',
        longitude: 121.491800,
        latitude: 31.292000,
        iconPath: 'https://img.icons8.com/color/48/0066ff/package.png',
        width: 40,
        height: 40,
        isTask: false
      }
    ]

    this.setData({ markers: campusPOIs })
  },

  loadNearbyTasks() {
    api.get('/map/tasks/nearby', {
      lng: this.data.centerLongitude,
      lat: this.data.centerLatitude,
      radius: 5000
    }).then(data => {
      if (data.tasks && data.tasks.length > 0) {
        const taskMarkers = data.tasks.map((t, i) => ({
          id: 100 + i,
          taskId: t.Task_ID,
          title: t.Title,
          address: `${t.Task_Location} | ¥${t.Reward} | ${t.Distance}m`,
          longitude: t.Location_Lng,
          latitude: t.Location_Lat,
          iconPath: 'https://img.icons8.com/color/48/ff6600/marker.png',
          width: 30,
          height: 30,
          isTask: true
        }))
        this.setData({
          markers: this.data.markers.concat(taskMarkers)
        })
      }
    }).catch(() => {})
  },

  // 定位到我的位置
  goToMyLocation() {
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        this.setData({
          centerLongitude: res.longitude,
          centerLatitude: res.latitude,
          polyline: [] // 清除之前的路线
        });
        wx.showToast({
          title: '已定位到当前位置',
          icon: 'success',
          duration: 1500
        });
      },
      fail: () => {
        wx.showToast({
          title: '定位失败，请检查权限',
          icon: 'none'
        });
      }
    });
  },

  // 地图缩放
  zoomIn() {
    this.setData({
      mapScale: Math.min(this.data.mapScale + 1, 20)
    });
  },

  zoomOut() {
    this.setData({
      mapScale: Math.max(this.data.mapScale - 1, 10)
    });
  },

  // 点击地图标记点
  onMarkerClick(e) {
    const markerId = e.detail.markerId
    const poi = this.data.markers.find(item => item.id === markerId)

    if (poi) {
      if (poi.isTask && poi.taskId) {
        wx.navigateTo({ url: `/pages/task-detail/task-detail?id=${poi.taskId}` })
      } else {
        this.setData({ currentPoi: poi, showPoiPopup: true })
      }
    }
  },

  // 点击地图空白处关闭弹窗
  onMapTap() {
    this.setData({ showPoiPopup: false })
  },

  // 关闭地点详情弹窗
  closePoiPopup() {
    this.setData({ showPoiPopup: false })
  },

  // 阻止事件冒泡
  stopPropagation() {},

  // 搜索输入
  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value })
  },

  // 执行搜索（通过后端API）
  doSearch() {
    const keyword = this.data.searchKeyword.trim()
    if (!keyword) {
      wx.showToast({ title: '请输入搜索内容', icon: 'none' })
      return
    }

    wx.showLoading({ title: '正在搜索...' })

    api.get('/tasks', { page: 1, per_page: 20 }).then(data => {
      wx.hideLoading()
      const filtered = (data.tasks || []).filter(t =>
        t.Title.includes(keyword) ||
        t.Task_Location.includes(keyword) ||
        t.Task_Type.includes(keyword)
      )

      if (filtered.length === 0) {
        wx.showToast({ title: '未找到相关任务', icon: 'none' })
        return
      }

      const searchMarkers = filtered
        .filter(t => t.Location_Lng && t.Location_Lat)
        .map((t, i) => ({
          id: 200 + i,
          taskId: t.Task_ID,
          title: t.Title,
          address: `${t.Task_Type} | ¥${t.Reward}`,
          longitude: t.Location_Lng,
          latitude: t.Location_Lat,
          iconPath: 'https://img.icons8.com/color/48/ff6600/marker.png',
          width: 30,
          height: 30,
          isTask: true
        }))

      if (searchMarkers.length > 0) {
        this.setData({
          markers: searchMarkers,
          centerLongitude: searchMarkers[0].longitude,
          centerLatitude: searchMarkers[0].latitude,
          polyline: []
        })
        wx.showToast({ title: `找到${searchMarkers.length}个任务`, icon: 'success' })
      } else {
        wx.showToast({ title: '找到相关任务但缺少位置信息', icon: 'none' })
      }
    }).catch(() => wx.hideLoading())
  },

  // 导航到选中地点
  navigateToPoi() {
    const poi = this.data.currentPoi;
    wx.openLocation({
      latitude: poi.latitude,
      longitude: poi.longitude,
      name: poi.title,
      address: poi.address,
      scale: 18
    });
  }
});