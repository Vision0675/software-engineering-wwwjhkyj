const api = require('../../utils/api')

Page({
  data: {
    task: null,
    loading: true
  },

  onLoad(options) {
    if (options.id) {
      this.loadTask(options.id)
    }
  },

  loadTask(id) {
    this.setData({ loading: true })
    api.get(`/tasks/${id}`)
      .then(data => this.setData({ task: data, loading: false }))
      .catch(() => this.setData({ loading: false }))
  },

  acceptTask() {
    const app = getApp()
    if (!app.checkLogin()) return

    wx.showModal({
      title: '确认接单',
      content: '接单后请按时完成任务，违约将扣除信用分',
      success: (res) => {
        if (res.confirm) {
          api.post(`/tasks/${this.data.task.Task_ID}/accept`)
            .then(() => {
              wx.showToast({ title: '接单成功', icon: 'success' })
              this.loadTask(this.data.task.Task_ID)
            })
        }
      }
    })
  },

  completeTask() {
    wx.showModal({
      title: '确认完成',
      content: '确认任务已完成？确认后资金和积分将发放给接单人',
      success: (res) => {
        if (res.confirm) {
          api.post(`/tasks/${this.data.task.Task_ID}/complete`)
            .then(() => {
              wx.showToast({ title: '已完成', icon: 'success' })
              this.loadTask(this.data.task.Task_ID)
            })
        }
      }
    })
  },

  goToChat() {
    wx.navigateTo({ url: `/pages/chat/chat?taskId=${this.data.task.Task_ID}` })
  },

  callContact() {
    wx.makePhoneCall({ phoneNumber: this.data.task.publisher_phone })
  },

  copyText(e) {
    wx.setClipboardData({ data: e.currentTarget.dataset.text })
    wx.showToast({ title: '已复制', icon: 'none' })
  }
})
