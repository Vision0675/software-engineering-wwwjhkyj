const api = require('../../utils/api')

Page({
  data: {
    taskTypes: ['跑腿代办', '学习互助', '技能服务'],
    taskTypeIndex: 0,
    title: '',
    description: '',
    reward: '',
    location: '',
    deadline: '',
    submitting: false
  },

  onTypeChange(e) {
    this.setData({ taskTypeIndex: e.detail.value })
  },

  onDeadlineChange(e) {
    this.setData({ deadline: e.detail.value })
  },

  submit() {
    const { taskTypes, taskTypeIndex, title, description, reward, location, deadline } = this.data

    if (!title.trim()) {
      wx.showToast({ title: '请输入任务标题', icon: 'none' })
      return
    }
    if (!location.trim()) {
      wx.showToast({ title: '请输入任务地点', icon: 'none' })
      return
    }

    this.setData({ submitting: true })

    api.post('/tasks', {
      Task_Type: taskTypes[taskTypeIndex],
      Title: title.trim(),
      Description: description.trim(),
      Reward: parseFloat(reward) || 0,
      Task_Location: location.trim(),
      Deadline: deadline || null
    }).then(() => {
      wx.showToast({ title: '发布成功，等待审核', icon: 'success' })
      setTimeout(() => wx.navigateBack(), 1500)
    }).finally(() => {
      this.setData({ submitting: false })
    })
  },

  chooseLocation() {
    wx.chooseLocation({
      success: (res) => {
        this.setData({
          location: res.name || res.address
        })
      }
    })
  }
})
