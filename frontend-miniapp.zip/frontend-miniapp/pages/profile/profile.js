const api = require('../../utils/api')
const app = getApp()

Page({
  data: {
    isLogin: false,
    userInfo: null,
    showRegister: false,
    registerForm: {
      Name: '',
      Student_ID: '',
      Department: '',
      Phone: ''
    },
    myPublished: [],
    myAccepted: []
  },

  onShow() {
    const token = app.globalData.token
    if (token) {
      this.loadProfile()
      this.loadMyTasks()
    }
  },

  // 微信登录
  wxLogin() {
    wx.getUserProfile({
      desc: '用于注册共济校圈账号',
      success: (res) => {
        // 模拟：实际需要 wx.login 获取 code 换取 openid
        // 这里直接进入注册流程
        this.setData({
          showRegister: true,
          'registerForm.Name': res.userInfo.nickName || ''
        })
      },
      fail: () => {
        wx.showToast({ title: '需要授权才能使用', icon: 'none' })
      }
    })
  },

  // 注册
  doRegister() {
    const form = this.data.registerForm
    if (!form.Name || !form.Student_ID || !form.Department || !form.Phone) {
      wx.showToast({ title: '请填写完整信息', icon: 'none' })
      return
    }

    api.post('/auth/register', {
      Name: form.Name,
      Student_ID: form.Student_ID,
      Department: form.Department,
      Phone: form.Phone,
      OpenID: 'wx_' + form.Student_ID  // 实际应从 wx.login 获取
    }).then(data => {
      wx.setStorageSync('token', data.token)
      app.globalData.token = data.token
      this.setData({ showRegister: false, isLogin: true })
      this.loadProfile()
      wx.showToast({ title: '注册成功', icon: 'success' })
    })
  },

  loadProfile() {
    api.get('/user/profile').then(data => {
      this.setData({ isLogin: true, userInfo: data })
      app.globalData.userInfo = data
    }).catch(() => {
      this.setData({ isLogin: false, userInfo: null })
    })
  },

  loadMyTasks() {
    api.get('/user/tasks/published').then(data => {
      this.setData({ myPublished: data.tasks || [] })
    }).catch(() => {})
    api.get('/user/tasks/accepted').then(data => {
      this.setData({ myAccepted: data.tasks || [] })
    }).catch(() => {})
  },

  // 退出登录
  logout() {
    wx.removeStorageSync('token')
    app.globalData.token = ''
    app.globalData.userInfo = null
    this.setData({
      isLogin: false,
      userInfo: null,
      showRegister: false,
      myPublished: [],
      myAccepted: []
    })
    wx.showToast({ title: '已退出', icon: 'none' })
  },

  goToTask(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({ url: `/pages/task-detail/task-detail?id=${id}` })
  },

  // 注册表单更新
  onFieldChange(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ [`registerForm.${field}`]: e.detail.value })
  }
})
