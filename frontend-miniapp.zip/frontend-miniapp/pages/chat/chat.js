const api = require('../../utils/api')
const app = getApp()

Page({
  data: {
    taskId: '',
    taskTitle: '',
    messages: [],
    inputText: '',
    currentUserId: ''
  },

  onLoad(options) {
    this.setData({ taskId: options.taskId })

    // Load task info
    api.get(`/tasks/${options.taskId}`)
      .then(data => this.setData({ taskTitle: data.Title }))

    // Load messages
    this.loadMessages()
  },

  loadMessages() {
    api.get(`/tasks/${this.data.taskId}/messages`)
      .then(data => {
        this.setData({
          messages: data.messages,
          currentUserId: app.globalData.userInfo?.User_ID || ''
        })
        this.scrollToBottom()
      })
  },

  sendMessage() {
    const text = this.data.inputText.trim()
    if (!text) return

    const msg = {
      Sender_ID: 'self',
      Content: text,
      Send_Time: new Date().toISOString(),
      sending: true
    }

    this.setData({
      messages: [...this.data.messages, msg],
      inputText: ''
    })
    this.scrollToBottom()

    api.post(`/tasks/${this.data.taskId}/messages`, {
      Content: text,
      Msg_Type: 0
    }).then(() => {
      this.loadMessages()
    }).catch(() => {
      msg.sending = false
      msg.failed = true
      this.setData({ messages: this.data.messages })
    })
  },

  onInput(e) {
    this.setData({ inputText: e.detail.value })
  },

  scrollToBottom() {
    setTimeout(() => {
      wx.createSelectorQuery()
        .select('#msgList')
        .boundingClientRect()
        .exec(() => {
          wx.pageScrollTo({ scrollTop: 99999, duration: 100 })
        })
    }, 100)
  }
})
