App({
  globalData: {
    baseURL: 'http://localhost:8080/api/v1',
    wsURL: 'ws://localhost:8080',
    token: '',
    userInfo: null
  },

  onLaunch() {
    const token = wx.getStorageSync('token')
    if (token) {
      this.globalData.token = token
    }
  },

  checkLogin() {
    if (!this.globalData.token) {
      wx.navigateTo({ url: '/pages/profile/profile' })
      return false
    }
    return true
  }
})
