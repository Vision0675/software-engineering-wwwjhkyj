const app = getApp()

function request(method, path, data) {
  const header = { 'Content-Type': 'application/json' }
  const token = app.globalData.token
  if (token) {
    header['Authorization'] = `Bearer ${token}`
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: app.globalData.baseURL + path,
      method,
      header,
      data,
      success(res) {
        if (res.statusCode === 200 && res.data.code === 20000) {
          resolve(res.data.data)
        } else if (res.data.code === 40100) {
          wx.removeStorageSync('token')
          app.globalData.token = ''
          wx.showToast({ title: '请先登录', icon: 'none' })
          reject(res.data)
        } else {
          wx.showToast({ title: res.data.message || '请求失败', icon: 'none' })
          reject(res.data)
        }
      },
      fail(err) {
        wx.showToast({ title: '网络异常', icon: 'none' })
        reject(err)
      }
    })
  })
}

module.exports = {
  get: (path, data) => request('GET', path, data),
  post: (path, data) => request('POST', path, data),
  put: (path, data) => request('PUT', path, data),
  del: (path, data) => request('DELETE', path, data)
}
